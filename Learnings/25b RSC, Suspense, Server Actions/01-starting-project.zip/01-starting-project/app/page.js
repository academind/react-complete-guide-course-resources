export default function Home() {
  return (
    <main>
      <p>Let's go!</p>
    </main>
  );
}
