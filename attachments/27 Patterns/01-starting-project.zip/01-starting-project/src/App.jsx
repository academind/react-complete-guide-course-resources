function App() {
  return <h1>React Patterns & Practices</h1>;
}

export default App;
